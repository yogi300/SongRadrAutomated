package com.songtradr.util;

public class Xpaths {
	public String loginButton = "//button[text()='Log In']";
	public String id = "//input[@id='EmailAddress']";
	public String password= "//input[@id='Password']";
	//public String Captchaclick = "//*[contains(@role,'checkbox')]/div";
	public String sitekey= "//iframe[contains(@src, 'https://www.google.com/recaptcha/api2')]";
	public String login = "//span[text()='Log In']";

//death by captcha id and password : kegelbrother Steuer99
	//"//iframe[contains(@src, 'https://www.google.com/recaptcha/api2')]"
}
